import { eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, students, InsertStudent } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getStudents(filters?: {
  search?: string;
  status?: string;
  graduationYear?: number;
  university?: string;
  qualification?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(students);

  if (filters?.search) {
    const searchTerm = `%${filters.search}%`;
    query = query.where(
      sql`${students.name} LIKE ${searchTerm} OR ${students.nationalNumber} LIKE ${searchTerm}`
    ) as any;
  }

  if (filters?.status) {
    query = query.where(eq(students.status, filters.status as "مستوفى" | "غير مستوفى")) as any;
  }

  if (filters?.graduationYear) {
    query = query.where(eq(students.graduationYear, filters.graduationYear)) as any;
  }

  if (filters?.university) {
    query = query.where(eq(students.university, filters.university)) as any;
  }

  if (filters?.qualification) {
    query = query.where(eq(students.qualification, filters.qualification)) as any;
  }

  return query;
}

export async function getStudentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createStudent(student: InsertStudent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(students).values(student);
  return result;
}

export async function updateStudent(id: number, student: Partial<InsertStudent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.update(students).set(student).where(eq(students.id, id));
  return result;
}

export async function deleteStudent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.delete(students).where(eq(students.id, id));
  return result;
}

export async function getStudentStats() {
  const db = await getDb();
  if (!db) return null;

  const allStudents = await db.select().from(students);
  
  const stats = {
    total: allStudents.length,
    byStatus: {} as Record<string, number>,
    byUniversity: {} as Record<string, number>,
    byGraduationYear: {} as Record<number, number>,
    byQualification: {} as Record<string, number>,
  };

  allStudents.forEach((student) => {
    stats.byStatus[student.status] = (stats.byStatus[student.status] || 0) + 1;
    stats.byUniversity[student.university] = (stats.byUniversity[student.university] || 0) + 1;
    stats.byGraduationYear[student.graduationYear] = (stats.byGraduationYear[student.graduationYear] || 0) + 1;
    stats.byQualification[student.qualification] = (stats.byQualification[student.qualification] || 0) + 1;
  });

  return stats;
}
